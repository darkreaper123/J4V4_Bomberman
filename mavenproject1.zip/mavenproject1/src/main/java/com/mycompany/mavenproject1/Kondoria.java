/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author DELL
 */
import java.util.List;
import javafx.scene.image.Image;
import javafx.scene.canvas.*;
import javafx.scene.canvas.GraphicsContext;
public class Kondoria extends Enemy{
    Kondoria()
    {
        
    }
    Kondoria(double x, double y, double width, double height, String name)
    {
        super(x, y, width, height, name);
    }
    public void move(AbstractObject object_copy[][], map map_copy, Player win, List<AbstractObject>enemy, List<Bomb>bomb)
    {
        AbstractObject[][] other = object_copy;
        int j_copy = (int)((object_X + distance_X)/ object_width);
        int i_copy = (int)((object_Y + distance_Y)/ object_height);
        int pick_choose = -1, currentX, currentY;
        check_grass = checkGrass(object_copy, map_copy);
        if(smart_move && !check_smart)
        {
            int i_player = (int)((win.object_X + win.distance_X) / win.object_width);
            int j_player = (int)((win.object_Y + win.distance_Y) / win.object_height);
            int distance = (int)Math.sqrt((i_player - i_copy) * (i_player - i_copy) + (j_player - j_copy) * (j_player - j_copy));
            if(distance <= smart_begin)
            {
                check_grass = false;
                check_smart = true;
            }
            else check_grass = checkGrass(object_copy, map_copy);
        }
        if(check_smart && !check_pathExist) check_grass = checkGrass(object_copy, map_copy);
        while((!check_balloon) || (check_balloon && check_grass))
        {
            currentX = - 1;
            currentY = -1;
            while(currentX < 0 || currentY < 0 || currentX + 1 > map_copy.map_cols || currentY + 1 > map_copy.map_rows )
            {
                pick_choose = (int) (Math.random() * 4);
                currentX = j_copy + id_move[pick_choose][change_X];
                //System.out.println(currentX);
                currentY = i_copy  + id_move[pick_choose][change_Y];
                //System.out.println(currentY);
            }
            if(!check_oneEnd(enemy, currentX, currentY) && !check_bomb(currentX, currentY, bomb))
            {
                if((check_balloon && other[currentY][currentX] instanceof Grass) || (!check_balloon && (other[currentY][currentX] instanceof Brick || other[currentY][currentX] instanceof Grass)) )
                {
                    step = pick_choose;
                    check_move = true;
                    break;
                }
            }
        }
    }
    public void Move(AbstractObject object_copy[][], map map_copy, Player win, List<AbstractObject>enemy, List<Bomb>bomb)
    {
        if(!check_move) move(object_copy, map_copy, win, enemy, bomb);
        else
        {
            real_move();
            //System.out.println("djt cai con cak nha m");
        }
    }
}
