/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author DELL
 */
import javafx.scene.image.Image;
import javafx.scene.canvas.*;
import javafx.scene.canvas.GraphicsContext;
public class Bomb extends Object{
    Image[] state;
    Image[] boom_top;
    Image[] boom_left;
    Image[] boom_right;
    Image[] boom_down;
    Image[] boom_heart;
    int flame_size = 2;
    int id_state = 0;
    int id_top = 0;
    int id_left = 0;
    int id_right = 0;
    int id_down = 0;
    int id_heart = 0;
    int time_exploded = 3;
    int time_waitExploded = 30;
    int id_LR = 0;
    int id_UD = 0;
    String for_LR = "horizontal";
    String for_UD = "vertical";
    String text_boom = "explosion";
    boolean boom_exist = false;
    Image[] mid_LR;
    Image[] mid_UD;
    int check[][] = new int[13][31];
    boolean boom_sound = true;
    Bomb(double width, double height, int flame_size)
    {
        super(width, height ,width, height, "bomb", false, false, false);
        this.flame_size = flame_size;
        Image[] new_state = {
            new Image(object_name + ".png", object_width, object_height, false, false),
            new Image(object_name + "_1.png", object_width, object_height, false, false),
            new Image(object_name + "_2.png", object_width, object_height, false, false)
        };
        present_state = new_state[0];
        state = new_state;
        Image[] heart = {
            new Image(object_name + "_exploded.png", object_width, object_height, false, false),
            new Image(object_name + "_exploded1.png", object_width, object_height, false, false),
            new Image(object_name + "_exploded2.png", object_width, object_height, false, false)
        };
        boom_heart = heart;
        Image[] top = {
            new Image(text_boom + "_" + for_UD + "_" + "top_last.png", object_width, object_height, false, false),
            new Image(text_boom + "_" + for_UD + "_" + "top_last1.png", object_width, object_height, false, false),
            new Image(text_boom + "_" + for_UD + "_" + "top_last2.png", object_width, object_height, false, false)
        };
        boom_top = top;
        Image[] down = {
            new Image(text_boom + "_" + for_UD + "_" + "down_last.png", object_width, object_height, false, false),
            new Image(text_boom + "_" + for_UD + "_" + "down_last1.png", object_width, object_height, false, false),
            new Image(text_boom + "_" + for_UD + "_" + "down_last2.png", object_width, object_height, false, false)
        };
        boom_down = down;
        Image[] left = {
            new Image(text_boom + "_" + for_LR + "_" + "left_last.png", object_width, object_height, false, false),
            new Image(text_boom + "_" + for_LR + "_" + "left_last1.png", object_width, object_height, false, false),
            new Image(text_boom + "_" + for_LR + "_" + "left_last2.png", object_width, object_height, false, false)
        };
        boom_left = left;
        Image[] right = {
            new Image(text_boom + "_" + for_LR + "_" + "right_last.png", object_width, object_height, false, false),
            new Image(text_boom + "_" + for_LR + "_" + "right_last1.png", object_width, object_height, false, false),
            new Image(text_boom + "_" + for_LR + "_" + "right_last2.png", object_width, object_height, false, false)
        };
        boom_right = right;
        Image[] LR = {
            new Image(text_boom + "_" + for_LR + ".png", object_width, object_height, false, false),
            new Image(text_boom + "_" + for_LR + "1.png", object_width, object_height, false, false),
            new Image(text_boom + "_" + for_LR + "2.png", object_width, object_height, false, false)
        };
        mid_LR = LR;
        Image[] UD = {
            new Image(text_boom + "_" + for_UD + ".png", object_width, object_height, false, false),
            new Image(text_boom + "_" + for_UD + "1.png", object_width, object_height, false, false),
            new Image(text_boom + "_" + for_UD + "2.png", object_width, object_height, false, false)
        };
        mid_UD = UD;
    }
    public static boolean check_Valid(int X_col, int Y_row,  AbstractObject[][] other)
    {
        return (X_col >= 0) && (Y_row >= 0) && (X_col < 31) && (Y_row < 13) && !(other[Y_row][X_col] instanceof Portal  || other[Y_row][X_col] instanceof Wall || other[Y_row][X_col] instanceof Item);
    }
    public static boolean check_stable(int X_col, int Y_row,  AbstractObject[][] other, int X_max, int Y_max, int alpha, boolean check_X)
    {
        boolean cak = false;
        return cak;
    }
    void renderBomb(GraphicsContext gc, AbstractObject[][] other)
    {
        if(boom_exist)
        {
            if (boom_sound) {
                Music m = new Music();
                m.bombeffect();
                boom_sound = false;
            }
            if(time_waitExploded > 0)
            {
                present_state = state[id_state];
                id_state = (id_state + 1)%3;
                time_waitExploded--;
            }
            else
            {
               if(time_exploded > 0)
               {
                   Music m = new Music();
                   m.bombboom();
                   present_state = boom_heart[id_heart++];
                   int X_col = (int)((object_X + distance_X)/ object_width);
                   int Y_row = (int)((object_Y + distance_Y) / object_height);
                   for(int i = 1;i <= flame_size;++i)
                   {
                       if(check_Valid(X_col - i, Y_row, other)) 
                       {
                           if(!(other[Y_row][X_col - i + 1] instanceof Brick) && (check[Y_row][X_col - i + 1] == 1 || i == 1)) 
                           {
                               check[Y_row][X_col - i] = 1;
                               if(i == flame_size) gc.drawImage(boom_left[id_left], object_X + distance_X - i * object_width, object_Y + distance_Y);
                               else gc.drawImage(mid_LR[id_left], object_X + distance_X - i * object_width, object_Y + distance_Y);
                           }
                       }
                       if(check_Valid(X_col + i, Y_row, other))
                       {
                           if(!(other[Y_row][X_col + i - 1] instanceof Brick) && (check[Y_row][X_col + i - 1] == 1 || i == 1)) 
                           {
                               check[Y_row][X_col + i] = 1;
                               if(i == flame_size) gc.drawImage(boom_right[id_right], object_X + distance_X +  i * object_width, object_Y + distance_Y);
                               else gc.drawImage(mid_LR[id_right], object_X + distance_X + i * object_width, object_Y + distance_Y);
                           }
                       }
                       if(check_Valid(X_col, Y_row - i, other))
                       {
                           if(!(other[Y_row - i + 1][X_col] instanceof Brick) && (check[Y_row - i + 1][X_col] == 1 || i == 1)) 
                           {
                               check[Y_row - i][X_col] = 1;
                               if(i == flame_size) gc.drawImage(boom_top[id_top], object_X + distance_X, object_Y - i * object_height + distance_Y);
                               else gc.drawImage(mid_UD[id_top], object_X + distance_X , object_Y - i * object_height + distance_Y);
                           }
                       }
                       if(check_Valid(X_col, Y_row + i, other)) 
                       {
                           if(!(other[Y_row  + i - 1][X_col] instanceof Brick) && (check[Y_row  + i - 1][X_col] == 1 || i == 1)) 
                           {
                               check[Y_row  + i][X_col] = 1;
                               if(i == flame_size) gc.drawImage(boom_down[id_down], object_X + distance_X, object_Y + i * object_height + distance_Y);
                               else gc.drawImage(mid_UD[id_down], object_X + distance_X , object_Y + i * object_height + distance_Y);
                           }
                       }
                       check[Y_row][X_col] = 1;
                   }
                   id_UD += 1;
                   id_LR +=1;
                   id_left++;
                   id_right++;
                   id_top++;
                   id_down++;
                   time_exploded--;
               }
               else
               {
                   id_state = 0;
                   id_left = 0;
                   id_right = 0;
                   id_top = 0;
                   id_down = 0;
                   id_heart = 0;
                   id_UD = 0;
                   id_LR = 0;
                   time_waitExploded = 30;
                   time_exploded = 3;
                   boom_exist = false;
                   check = new int[13][31];
               }
            }
            super.render(gc);
        }
    }
}
