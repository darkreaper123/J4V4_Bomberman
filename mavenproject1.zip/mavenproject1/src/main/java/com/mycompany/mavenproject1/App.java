package com.mycompany.mavenproject1;

import javafx.application.Application;
import javafx.scene.*;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.scene.canvas.*;
import javafx.animation.AnimationTimer;
import javafx.scene.input.KeyEvent;
import javafx.event.EventHandler;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.util.Duration;
import javafx.animation.KeyFrame;

/**
 * JavaFX App
 */
public class App extends Application {

    @Override
    public void start(Stage stage) {
        Music m = new Music();
        m.music();
        buildScene game_scene = new buildScene();
        buildScene reset = game_scene;
        stage.setTitle("Bomberman");
        Group root = new Group();
        Scene theScene = new Scene( root );
        stage.setScene( theScene );
        Canvas canvas = new Canvas( game_scene.game_map.width_screen, game_scene.game_map.height_screen);
        root.getChildren().add(canvas);
        GraphicsContext gc = canvas.getGraphicsContext2D();
        //final long startNanoTime = System.nanoTime();
        Timeline frame = new Timeline();
        frame.setCycleCount(Timeline.INDEFINITE);
        frame.getKeyFrames().add( new KeyFrame(
                Duration.millis(60),
                (ActionEvent e)-> {
                    gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
                    if(game_scene.win.win_tricky(game_scene.all_object, game_scene.enemy) || !game_scene.win.render_orNot) game_scene.reset_game = true;
                    if(game_scene.reset_game)
                    {
                        game_scene.reset();
                    }
                    else
                    {
                        //game_scene.moveEnemy();
                        game_scene.updatePortal();
                        game_scene.win.recover_Bomb();
                        game_scene.player_die();
                        if(!game_scene.win.check_die) game_scene.create_Boss();
                        game_scene.render(gc);
                        theScene.setOnKeyPressed(new EventHandler<KeyEvent>(){
                            public void handle(KeyEvent e){
                                game_scene.playerMove(e, game_scene.win.my_bomb);
                            }  
                        });
                        if(!game_scene.win.check_die)
                        {
                            game_scene.moveEnemy();
                        }
                        if(game_scene.win.check_move && game_scene.win.move_able) game_scene.win.real_move();
                        //game_scene.win.setMove(false);
                    }
                }
        ));
        frame.play();
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);

        
    }

}