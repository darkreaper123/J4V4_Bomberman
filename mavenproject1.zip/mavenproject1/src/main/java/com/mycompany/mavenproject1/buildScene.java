/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author DELL
 */
import javafx.animation.Timeline;
import javafx.util.Duration;
import javafx.animation.KeyFrame;
import javafx.event.ActionEvent;
import javafx.scene.image.Image;
import javafx.scene.canvas.*;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.KeyCode;
import java.util.List;
import java.util.ArrayList;
public class buildScene {
    Music game_music;
    map game_map;
    AbstractObject[][] all_object;
    Player win;
    boolean reset_game = false;
    int check[][];
    List<AbstractObject>enemy = new ArrayList<AbstractObject>();
    buildScene()
    {
        //game_map.readFile();
        reset_game = false;
        game_map = new map();
        win = new Player(game_map.size_object, game_map.size_object);
        all_object = new AbstractObject[game_map.map_rows][game_map.map_cols];
        check = new int[game_map.map_rows][game_map.map_cols];
        int x = 0;
        for(int i = 0;i < game_map.map_rows;++i)
        {
            for(int j = 0;j < game_map.map_cols;++j)
            {
                System.out.print(game_map.map_char[i][j]);
                if(Character.toString(game_map.map_char[i][j]).equals("1"))
                {
                    all_object[i][j] = new Grass(game_map.size_object * j, game_map.size_object * i, game_map.size_object, game_map.size_object);
                    enemy.add(new Balloon(game_map.size_object * j, game_map.size_object * i, game_map.size_object, game_map.size_object, "balloom"));
                }
                else if(Character.toString(game_map.map_char[i][j]).equals("2"))
                {
                    enemy.add(new Oneal(game_map.size_object * j, game_map.size_object * i, game_map.size_object, game_map.size_object, "oneal"));
                    all_object[i][j] = new Grass(game_map.size_object * j, game_map.size_object * i, game_map.size_object, game_map.size_object);
                }
                else if(Character.toString(game_map.map_char[i][j]).equals("3"))
                {
                    enemy.add(new Kondoria(game_map.size_object * j, game_map.size_object * i, game_map.size_object, game_map.size_object, "kondoria"));
                    all_object[i][j] = new Grass(game_map.size_object * j, game_map.size_object * i, game_map.size_object, game_map.size_object);
                }
                else if(Character.toString(game_map.map_char[i][j]).equals("#"))
                {
                    all_object[i][j] = new Wall(game_map.size_object * j, game_map.size_object * i, game_map.size_object, game_map.size_object);
                }
                else if(Character.toString(game_map.map_char[i][j]).equals("*"))
                {
                    all_object[i][j] = new Brick(game_map.size_object * j, game_map.size_object * i, game_map.size_object, game_map.size_object);
                }
                //if(game_map.map_char[i][j] == ' ')
                else if(Character.toString(game_map.map_char[i][j]).equals("s") || Character.toString(game_map.map_char[i][j]).equals("f") || Character.toString(game_map.map_char[i][j]).equals("b"))
                {
                    all_object[i][j] = new Brick(game_map.size_object * j, game_map.size_object * i, game_map.size_object, game_map.size_object);
                    //all_object[i][j] = new Item(game_map.size_object * j, game_map.size_object * i, game_map.size_object, game_map.size_object, game_map.map_char[i][j]);
                }
                else
                {
                    all_object[i][j] = new Grass(game_map.size_object * j, game_map.size_object * i, game_map.size_object, game_map.size_object);
                }
            }
            System.out.println("");
        }
    }
    void reset()
    {
        go_portal = false;
        check_portal = false;
        reset_game = false;
        game_map = new map();
        win = new Player(game_map.size_object, game_map.size_object);
        all_object = new AbstractObject[game_map.map_rows][game_map.map_cols];
        enemy = new ArrayList<AbstractObject>();
        int x = 0;
        for(int i = 0;i < game_map.map_rows;++i)
        {
            for(int j = 0;j < game_map.map_cols;++j)
            {
                System.out.print(game_map.map_char[i][j]);
                if(Character.toString(game_map.map_char[i][j]).equals("1"))
                {
                    all_object[i][j] = new Grass(game_map.size_object * j, game_map.size_object * i, game_map.size_object, game_map.size_object);
                    enemy.add(new Balloon(game_map.size_object * j, game_map.size_object * i, game_map.size_object, game_map.size_object, "balloom"));
                }
                else if(Character.toString(game_map.map_char[i][j]).equals("2"))
                {
                    all_object[i][j] = new Grass(game_map.size_object * j, game_map.size_object * i, game_map.size_object, game_map.size_object);
                    enemy.add(new Oneal(game_map.size_object * j, game_map.size_object * i, game_map.size_object, game_map.size_object, "oneal"));
                }
                else if(Character.toString(game_map.map_char[i][j]).equals("3"))
                {
                    enemy.add(new Kondoria(game_map.size_object * j, game_map.size_object * i, game_map.size_object, game_map.size_object, "kondoria"));
                    all_object[i][j] = new Grass(game_map.size_object * j, game_map.size_object * i, game_map.size_object, game_map.size_object);
                }
                else if(Character.toString(game_map.map_char[i][j]).equals("#"))
                {
                    all_object[i][j] = new Wall(game_map.size_object * j, game_map.size_object * i, game_map.size_object, game_map.size_object);
                }
                else if(Character.toString(game_map.map_char[i][j]).equals("*"))
                {
                    all_object[i][j] = new Brick(game_map.size_object * j, game_map.size_object * i, game_map.size_object, game_map.size_object);
                }
                //if(game_map.map_char[i][j] == ' ')
                else if(Character.toString(game_map.map_char[i][j]).equals("s") || Character.toString(game_map.map_char[i][j]).equals("f") || Character.toString(game_map.map_char[i][j]).equals("b"))
                {
                    all_object[i][j] = new Brick(game_map.size_object * j, game_map.size_object * i, game_map.size_object, game_map.size_object);
                    //all_object[i][j] = new Item(game_map.size_object * j, game_map.size_object * i, game_map.size_object, game_map.size_object, game_map.map_char[i][j]);
                }
                else
                {
                    all_object[i][j] = new Grass(game_map.size_object * j, game_map.size_object * i, game_map.size_object, game_map.size_object);
                }
            }
            System.out.println("");
        }
    }
    public boolean check_enemyExist()
    {
       return enemy.size() > 0;
    }
    public boolean check_win()
    {
        if(!check_enemyExist()) 
        {
            System.out.println("You kill all the enemies !!");
        }
        return !check_enemyExist();
    }
    public boolean check_lose()
    {
       return false; 
    }
    void render(GraphicsContext gc)
    {
        
        for(int i = 0;i < game_map.map_rows;++i)
        {
            for(int j = 0;j < game_map.map_cols;++j)
            {
                all_object[i][j].render(gc);
            }
        }
        win.bomb_active(all_object, gc);
        renderDie(gc);
        for(int i = 0;i < enemy.size();++i) enemy.get(i).render(gc);
        win.render(gc);
    }
    void renderDie(GraphicsContext gc)
    {
        for(int i = 0;i < game_map.map_rows;++i)
        {
            for(int j = 0;j < game_map.map_cols;++j)
            {
                if(all_object[i][j] instanceof Brick &&  all_object[i][j].check_die) 
                {
                    all_object[i][j].render(gc);
                }
            }
        }
    }
    void moveEnemy()
    {
        System.out.println(enemy.size());
        for(int i = 0;i < game_map.map_rows;++i)
        {
            for(int j = 0;j < game_map.map_cols;++j)
            {
                if(all_object[i][j] instanceof Brick) 
                {
                    for(int a = 0;a < win.size_exist;++a)
                    {
                        all_object =  ((Brick)all_object[i][j]).state_die(all_object , win.my_bomb.get(a));
                        if(all_object[i][j].check_die && (Character.toString(game_map.map_char[i][j]).equals("s") || Character.toString(game_map.map_char[i][j]).equals("f") || Character.toString(game_map.map_char[i][j]).equals("b")))
                        {
                            all_object[i][j] = new Item(game_map.size_object * j, game_map.size_object * i, game_map.size_object, game_map.size_object, game_map.map_char[i][j]);
                        }
                    }
                }
            }
        }
        for(int i = 0;i < enemy.size();++i)
        {
            for(int j = 0;j < win.size_exist;++j)
            {
                if(enemy.get(i) instanceof Minvo)
                {
                    ((Minvo)enemy.get(i)).state_die(all_object, win.my_bomb.get(j));
                }
                if(enemy.get(i) instanceof Oneal)
                {
                    //System.out.println("djt");
                    ((Oneal)enemy.get(i)).state_die(all_object, win.my_bomb.get(j));
                }
                else if(enemy.get(i) instanceof Balloon)
                {
                    //System.out.println("loz");
                    ((Balloon)enemy.get(i)).state_die(all_object, win.my_bomb.get(j));
                }
                else
                {
                    ((Kondoria)enemy.get(i)).state_die(all_object, win.my_bomb.get(j));
                }
            }
            if(!enemy.get(i).check_die && enemy.get(i).render_orNot)
            {
                if(enemy.get(i) instanceof Minvo)
                {
                    ((Minvo)enemy.get(i)).Move(all_object, game_map, win, enemy, win.my_bomb);
                }
                if(enemy.get(i) instanceof Oneal) 
                {
                    ((Oneal)enemy.get(i)).Move(all_object, game_map, win, enemy, win.my_bomb);
                }
                else if(enemy.get(i) instanceof Balloon)
                {
                    ((Balloon)enemy.get(i)).Move(all_object, game_map, win, enemy, win.my_bomb);
                }
                else
                {
                    ((Kondoria)enemy.get(i)).Move(all_object, game_map, win, enemy, win.my_bomb);
                }
            }
            if(!enemy.get(i).render_orNot)
            {
                enemy.remove(i);
                i--;
            }
        }
    }
    void player_die()
    {
        if(win.check_collision(enemy)) win.check_die = true;
        for(int i = 0;i < win.size_exist;++i) 
        {
            win.bomb_kill(win.my_bomb.get(i));
        }
        all_object  = win.state_die(all_object);
    }
    void playerMove(KeyEvent e, List<Bomb>bomb)
    {
        if(win.move_able)
        {
            win.eat_item(all_object);
            //System.out.println(win.check_move);
            win.player_move(e, all_object);
        }
        
    }
    void create_Boss()
    {
        int count = 0;
        for(int i = 0;i < enemy.size() - count;++i)
        {
            boolean check = false;
            int save_j = -1;
            for(int j = 0;j < i;++j)
            {
               boolean check1 = (enemy.get(j) instanceof Kondoria && !(enemy.get(j) instanceof Balloon)) && (enemy.get(i) instanceof Oneal && !(enemy.get(i) instanceof Minvo));
               boolean check2 = (enemy.get(i) instanceof Kondoria && !(enemy.get(i) instanceof Balloon)) && (enemy.get(j) instanceof Oneal && !(enemy.get(j) instanceof Minvo));
               if(check1 || check2)
               {
                   int Xi = (int)(enemy.get(i).object_X + enemy.get(i).distance_X);
                   int Yi = (int)(enemy.get(i).object_Y + enemy.get(i).distance_Y);
                   int Xj = (int)(enemy.get(j).object_X + enemy.get(j).distance_X);
                   int Yj = (int)(enemy.get(j).object_Y + enemy.get(j).distance_Y);
                   boolean move_i = enemy.get(i).check_move;
                   boolean move_j = enemy.get(j).check_move;
                   if(Xi == Xj && Yi == Yj && !move_i && !move_j)
                   {
                       enemy.add(new Minvo(Xi, Yi, game_map.size_object, game_map.size_object, "minvo", true, 0));
                       check = true;
                       save_j = j;
                       break;
                   }
               }
            }
            if(check)
            {
                enemy.remove(i);
                enemy.remove(save_j);
                i-=2;
                count++;
                //System.out.println("co cai con cak");
            }
        }
        //System.out.println("loz");
    }
    boolean go_portal = false;
    boolean check_portal = false;
    public void updatePortal()
    {
        if(!check_enemyExist() && !check_portal)
        {
            check_portal = true;
            System.out.println("djt");
            for(int i = 0;i < game_map.map_rows;++i)
            {
                for(int j = 0;j < game_map.map_cols;++j)
                {
                    if(Character.toString(game_map.map_char[i][j]).equals("x"))
                    {
                        all_object[i][j] = new Portal(game_map.size_object * j, game_map.size_object * i, game_map.size_object, game_map.size_object);
                    }
                }
            }
        }
    }
}
