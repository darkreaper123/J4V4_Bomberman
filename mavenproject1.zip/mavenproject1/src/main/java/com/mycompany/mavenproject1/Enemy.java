/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author DELL
 * 
 */
import javafx.scene.image.Image;
import javafx.scene.canvas.*;
import javafx.scene.canvas.GraphicsContext;
import java.util.List;
public class Enemy extends Object {
    Player information;
    boolean smart_move  = false;
    int smart_begin = 10;
    boolean check_smart = false;
    boolean check_grass;
    boolean check_balloon = false;
    boolean check_pathExist = false;
    Enemy(){}
    public boolean checkGrass(AbstractObject[][] object_copy, map map_copy)
    {
        int x = (int)((this.object_X + this.distance_X) / this.object_width);
        //System.out.println(x);
        int y = (int)((this.object_Y + this.distance_Y) / this.object_height);
        //System.out.println(y);
        for(int i = Math.max(y - 1, 0);i <= Math.min(y + 1, map_copy.map_rows - 1);i+=(y - 1 >= 0 ? 2 : 1))
        {
            if(object_copy[i][x] instanceof Grass) return true;
        }
        for(int i = Math.max(x - 1, 0);i <= Math.min(x + 1, map_copy.map_cols - 1);i+=(x - 1 >= 0 ? 2 : 1))
        {
            if(object_copy[y][i] instanceof Grass) return true;
        }
        return false;
    }
    public boolean check_oneEnd(List<AbstractObject>enemy, int x, int y)
    {
        //boolean check = false;
        //for(int i = 0;i < enemy.size() && check;++i)
        //{
            //int enemy_X = (int)((enemy.get(i).object_X + enemy.get(i).distance_X) / object_width);
            //int enemy_Y = (int)((enemy.get(i).object_Y + enemy.get(i).distance_Y) / object_height);
            //if(enemy_X == x && enemy_Y == y) return true;
        //}
        return false;
    }
    Enemy(double x, double y, double width, double height, String name)
    {
        super(x, y, width, height, name, true, false, false);
        dead = new Image[1];
        dead[0] = new Image(name + "_dead.png");
        size_imgDie = 1;
        size_speed = 1;
    }
    public AbstractObject[][] state_die(AbstractObject[][] other, Bomb player_bomb)
    {
        bomb_kill(player_bomb);
        AbstractObject[][] new_object = super.state_die(other);
        return new_object;
    }
}
