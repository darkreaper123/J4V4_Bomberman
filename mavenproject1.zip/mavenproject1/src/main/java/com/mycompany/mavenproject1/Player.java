/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author DELL
 */
import javafx.scene.image.Image;
import javafx.scene.canvas.*;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.canvas.*;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.KeyCode;
import javafx.util.Pair;
import java.util.List;
import java.util.ArrayList;
public class Player extends Object {
    boolean reset_game = true;
    List<Bomb> my_bomb = new ArrayList<Bomb>();
    boolean place_bomb =false;
    int number_boom = 2;
    int size_exist = 0;
    boolean lose = false;
    int time_wait = 30;
    int flame_size = 1;
    int save_numberBomb;
    Player()
    {
        
    }
    Player(double width, double height)
    {
        super(width, height , width, height, "player", true, true, true);
        move_able = true;
        save_numberBomb = number_boom;
        size_speed = 3;
    }
    public static Pair<Integer, Integer> convert(KeyEvent e)
    {
        if(e.getCode() == KeyCode.LEFT) return new Pair<Integer, Integer>(-1,0);
        if(e.getCode() == KeyCode.RIGHT) return new Pair<Integer, Integer>(1,0);
        if(e.getCode() == KeyCode.UP) return new Pair<Integer, Integer>(0,-1);
        if(e.getCode() == KeyCode.DOWN) return new Pair<Integer, Integer>(0,1);
        return new Pair<Integer, Integer>(0, 0);
    }
    public boolean check_Valid(int X_col, int Y_row,  AbstractObject[][] other)
    {
        return !check_move && (X_col >= 0) && (Y_row >= 0) && (X_col < 31) && (Y_row < 13) && (other[Y_row][X_col] instanceof Grass || other[Y_row][X_col] instanceof Portal || other[Y_row][X_col] instanceof Enemy || other[Y_row][X_col] instanceof Item) && !check_bomb(X_col, Y_row, my_bomb);
    }
    public void player_move(KeyEvent e, AbstractObject[][] other)
    {
        Music m = new Music();
        m.soundmove();
        int X_col = (int)((object_X + distance_X) / object_width);
        int Y_row = (int)((object_Y + distance_Y) / object_height);
        if(e.getCode() == KeyCode.LEFT && check_Valid(X_col - 1, Y_row, other)) step = 0;
        if(e.getCode() == KeyCode.RIGHT && check_Valid(X_col + 1, Y_row, other)) step = 1;
        if(e.getCode() == KeyCode.UP && check_Valid(X_col, Y_row - 1, other)) step = 2;
        if(e.getCode() == KeyCode.DOWN && check_Valid(X_col, Y_row + 1, other)) step = 3;
        if(e.getCode() == KeyCode.LEFT || e.getCode() == KeyCode.RIGHT || e.getCode() == KeyCode.UP || e.getCode() == KeyCode.DOWN)
        {
            //System.out.print("djt cai con me");
            if(step != -1) check_move = true;
        }
        if(e.getCode() == KeyCode.SPACE) 
        {
            if(number_boom > 0)
            {
                my_bomb.add(new Bomb(object_width, object_height, flame_size)); 
                my_bomb.get(size_exist).distance_X = distance_X;
                my_bomb.get(size_exist).distance_Y = distance_Y;
                my_bomb.get(size_exist).boom_exist = true;
                size_exist++;
                number_boom --;
                place_bomb = true;
            }
        }
    }
    public void recover_Bomb()
    {
            if(time_wait > 0) time_wait --;
            else 
            {
                time_wait = 30;
                number_boom += ( number_boom < save_numberBomb ? 1 : 0);
            }
    }
    public void setMove(boolean other)
    {
        check_move = other;
    }
    public void bomb_active(AbstractObject[][] other, GraphicsContext gc)
    {
        if(place_bomb)
        {
            int max_size = size_exist;
            int count = 0;
            for(int i = 0;i < size_exist;++i)
            {
                my_bomb.get(i).renderBomb(gc , other);
                if(!my_bomb.get(i).boom_exist)
                {
                    count++;
                    my_bomb.remove(i);
                    i -= 1;
                    size_exist -= 1;
                }
            }
            if(count == max_size) place_bomb = false;
        }
    }
    public boolean win_tricky(AbstractObject[][] other, List<AbstractObject>enemy)
    {
        int x_col = (int)((object_X + distance_X)/object_width);
        int y_row = (int)((object_Y + distance_Y)/object_height);
        return (other[y_row][x_col] instanceof Portal && enemy.size() == 0);
    }
    public AbstractObject[][] eat_item(AbstractObject[][] other)
    {
    
        //Music m = new Music();
        //m.itemget();
        AbstractObject[][] new_object = other;
        int x_col = (int)((object_X + distance_X)/object_width);
        int y_row = (int)((object_Y + distance_Y)/object_height);
        if(other[y_row][x_col] instanceof Item) 
        {
            Music m = new Music();
            m.itemget();
            if(((Item)other[y_row][x_col]).item == 'f') flame_size++;
            if(((Item)other[y_row][x_col]).item == 'b') save_numberBomb++;
            new_object[y_row][x_col] = new Grass(x_col * object_width, y_row * object_height, object_width, object_height);
        }
        return new_object;
    }
    public AbstractObject[][] state_die(AbstractObject[][] other)
    {
        AbstractObject[][] other2 = super.state_die(other);
        if(!render_orNot) {
            check_die = true;
            Music m = new Music();
            m.diesound();
        }
        
        return other2;
    }
}
