/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

import java.util.List;

/**
 *
 * @author DELL
 */
public class Minvo extends Oneal{
    Minvo(){}
    Minvo(double x, double y, double width, double height, String name, boolean begin_move, int smart_id)
    {
        super(x, y, width, height, name, begin_move, smart_id);
        check_balloon = false;
        smart_move = false;
    }
}
