/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author DELL
 */
import java.util.ArrayList;
import java.util.List;
import javafx.scene.image.Image;
import javafx.scene.canvas.*;
import javafx.scene.canvas.GraphicsContext;
import javafx.util.Pair;
public class Oneal extends Balloon {
    Oneal(){}
    int smart_id = 0;
    boolean create_path = true;
    //findPath find_path;
    boolean begin_move = false;
    boolean begin_find = true;
    boolean check[][];
    int begin_X;
    int begin_Y;
    int end_X;
    int end_Y;
    int row_player;
    int col_player;
    boolean begin;
    Oneal(double x, double y, double width, double height, String name, boolean begin_move, int smart_id)
    {
        
        super(x, y, width, height, name);
        
        check = new boolean[13][31];
        for(int i = 0;i < 13;++i)
        {
            for(int j = 0;j < 31;++j) check[i][j] = false;
        }
        smart_move = true;
        //this.find_path = find_path;
        this.begin_move = begin_move;
        this.smart_id = smart_id;
    }
    ArrayList<Integer>shortest_path = new  ArrayList<Integer>();
    ArrayList<Integer>path = new ArrayList<Integer>(0);
    Oneal(double x, double y, double width, double height, String name)
    {
        super(x, y, width, height, name);
        smart_move = true;
        check = new boolean[13][31];
        for(int i = 0;i < 13;++i)
        {
            for(int j = 0;j < 31;++j) check[i][j] = false;
        }
    }
    Player copy;
    int next_step = -1;
    void shortestPath(int i, int j, AbstractObject[][] other, int id, List<AbstractObject>enemy)
    {
        if(true)
        {
            //System.out.println("djt cai con me nha chung m");
            boolean check_type = (!check[i][j] && ((check_balloon && other[i][j] instanceof Grass) || (!check_balloon && (other[i][j] instanceof Brick || other[i][j] instanceof Grass))));
            if(check_type || begin)
            {
                if(begin) begin = !begin;
                check[i][j] = true;
                path.add(id);
                if(i == row_player && j == col_player)
                {
                    if(shortest_path.isEmpty()) shortest_path = path;
                    else if(shortest_path.size() < path.size())
                    {
                        shortest_path = path;
                    }
                    next_step = shortest_path.get(1);
                    System.out.println("djt loz");
                    //System.out.println(shortest_path.size());
                }
                else
                {
                    if(i > begin_Y && !check_oneEnd(enemy, j, i - 1)) shortestPath(i - 1, j, other, 2, enemy);
                    if(i < end_Y && !check_oneEnd(enemy, j, i + 1)) shortestPath(i + 1, j, other, 3, enemy);
                    if(j > begin_X && !check_oneEnd(enemy, j - 1, i)) shortestPath(i, j - 1, other, 0, enemy);
                    if(j < end_X && !check_oneEnd(enemy, j + 1, i)) shortestPath(i, j + 1, other, 1, enemy);
                }
                check[i][j] = false;
                int max_size = path.size() - 1;
                path.remove(max_size);
            }
        }
    }
    public void move(AbstractObject object_copy[][], map map_copy, Player win, List<AbstractObject>enemy, List<Bomb>bomb)
    {
        super.move(object_copy, map_copy, win, enemy, bomb);
        if(check_smart)
        {
            int j = (int)((object_X + distance_X)/ object_width);
            int i = (int)((object_Y + distance_Y)/ object_height);
            end_X = (int)((win.object_X + win.distance_X)/win.object_width);
            col_player = end_X;
            end_Y = (int)((win.object_Y + win.distance_Y)/win.object_width);
            row_player = end_Y;
            begin_X = Math.min(j, end_X);
            end_X = Math.max(j, end_X);
            begin_Y = Math.min(i, end_Y);
            end_Y = Math.max(i, end_Y); 
            shortestPath(i, j, object_copy, -1, enemy);
            if(next_step == -1)
            {
                size_speed = 1;
                check_pathExist = false;
                //System.out.println("vacalol");
            }
            else
            {
                //System.out.println("holly fuck");
                size_speed = 2;
                check_pathExist = true;
                if(true)
                {
                    step = next_step;
                    check_move = true;
                    
                    //change_IMG(new Pair<Integer, Integer>(id_move[next_step][change_X], id_move[next_step][change_Y]));
                    next_step = -1;
                    shortest_path = new  ArrayList<Integer>();
                    path = new  ArrayList<Integer>();
                    //other[i][j] = new Grass(map_copy.size_object * j, map_copy.size_object * i, object_width, object_height);
                    //other[i][j].save_X = currentX;
                    //other[i][j].save_Y = currentY;
                }
            }
        }
    }
    public void Move(AbstractObject object_copy[][], map map_copy, Player win, int check[][], List<AbstractObject>enemy, List<Bomb>bomb)
    {
        if(!check_move) move(object_copy, map_copy, win, enemy, bomb);
        else
        {
            real_move();
        }
    }
}
