/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.util.Pair;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author DELL
 */
public abstract class AbstractObject {
    //boolean check_die;
    int size_left = 3;
    int size_right = 3;
    int size_up = 3;
    int size_down = 3;
    int save_X;
    int save_y;
    int size_imgDie = 3;
    boolean check_move  = false;
    int number_move = 3;
    int save_Y = -1;
    int save_pick = -1;
    boolean start_move = true;
    String object_name;
    boolean st_Alive;
    boolean can_upDown;
    boolean can_leftRight;
    Image[] go_left;
    Image[] go_right;
    Image[] go_up;
    Image[] go_down;
    Image[] dead;
    Image present_state;
    double distance_X = 0.0;
    double distance_Y = 0.0;
    double object_X;
    double object_Y;
    double object_width = 48;
    double object_height = 48;
    public abstract void render(GraphicsContext gc);
    public abstract void move();
    public abstract void image_UD();
    public int id_up;
    public boolean check_up;
    public int id_down;
    public boolean check_down;
    public abstract void image_LR();
    public int id_left;
    public boolean check_left;
    public int id_right;
    public boolean check_right;
    public abstract void die();
    public abstract void change_IMG(Pair<Integer, Integer>move_number);
    public abstract void set_Id(AbstractObject other);
    //public Pair<Integer, Integer>move_number;
    public boolean check_die;
    public boolean move_able;
    int number_die = 3;
    public int id_die = 0;
    boolean render_orNot = true;
    public abstract boolean check_collision(List<AbstractObject>enemy);
    public abstract AbstractObject[][] state_die(AbstractObject[][] other);
    public abstract void bomb_kill(Bomb player_bomb);
    public abstract void real_move();
    int change_X = 0;
    int change_Y = 1;
    int[][] id_move = {
        {-1,0},
        {1,0},
        {0, -1},
        {0, 1}
    };
    int step = -1;
}
