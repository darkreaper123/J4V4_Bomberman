/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author DELL
 */
import javafx.scene.image.Image;
import javafx.scene.canvas.*;
import javafx.scene.canvas.GraphicsContext;
public class CanBreaked extends ObjectStable {
    CanBreaked(double x, double y, double width, double height, String name)
    {
        super(x, y, width, height, name);
        Image[] image_explosed = {
          new Image(name + "_exploded.png", object_width, object_height, false, false),
          new Image(name + "_exploded1.png", object_width, object_height, false, false),
          new Image(name + "_exploded2.png", object_width, object_height, false, false)
        };
        dead = image_explosed;
    }
}
