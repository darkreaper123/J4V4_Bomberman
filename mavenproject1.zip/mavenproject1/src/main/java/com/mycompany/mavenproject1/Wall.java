/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author DELL
 */
public class Wall extends ObjectStable {
    Wall(double x, double y, double width, double height)
    {
        super(x, y, width, height, "wall");
    }
}
