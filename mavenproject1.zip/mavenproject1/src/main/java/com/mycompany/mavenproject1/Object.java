/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

import javafx.scene.image.Image;
import javafx.scene.canvas.*;
import javafx.scene.canvas.GraphicsContext;
import javafx.util.Pair;
import java.util.List;

/**
 *
 * @author DELL
 */
public class Object extends AbstractObject {
    int count_move = 0;
    Object()
    {
        
    }
    Object(double x, double y, double width, double height, String name)
    {
        object_name = name;
        object_width = width;
        object_height = height;
        object_X = x;
        object_Y = y;
    }
    Object(double x, double y, double width, double height, String name , boolean left_right, boolean up_down, boolean alive)
    {
        can_leftRight = left_right;
        st_Alive = alive;
        can_upDown = up_down;
        object_name = name;
        object_width = width;
        object_height = height;
        object_X = x;
        object_Y = y;
        if(left_right)
        {
            Image[] left = {
                new Image(object_name + "_left1.png", object_width, object_height, false, false),
                new Image(object_name + "_left2.png", object_width, object_height, false, false),
                new Image(object_name + "_left3.png", object_width, object_height, false, false)
            };
            go_left = left;
            Image[] right = {
                new Image(object_name + "_right1.png", object_width, object_height, false, false),
                new Image(object_name + "_right2.png", object_width, object_height, false, false),
                new Image(object_name + "_right3.png", object_width, object_height, false, false)
            };
            go_right = right;
            present_state  = right[0];
        }
        if(up_down)
        {
            Image[] up = {
                new Image(object_name + "_up1.png", object_width, object_height, false, false),
                new Image(object_name + "_up2.png", object_width, object_height, false, false),
                new Image(object_name + "_up3.png", object_width, object_height, false, false)
            };
            go_up = up;
            Image[] down = {
                 new Image(object_name + "_down1.png", object_width, object_height, false, false),
                new Image(object_name + "_down2.png", object_width, object_height, false, false),
                new Image(object_name + "_down3.png", object_width, object_height, false, false)
            };
        go_down = down;
        }
        if(alive)
        {
            Image[] die = {
                new Image(object_name + "_dead1.png", object_width, object_height, false, false),
                new Image(object_name + "_dead2.png", object_width, object_height, false, false),
                new Image(object_name + "_dead3.png", object_width, object_height, false, false)
            };
            dead = die;
        }
    }
    public void render(GraphicsContext gc)
    {
        if(render_orNot)
        {
            gc.drawImage(present_state , object_X + distance_X, object_Y + distance_Y);
        }
    }
    public void move()
    {
        
    }
    public void remove_state()
    {
        check_up = false;
        check_down = false;
        check_left = false;
        check_right = false;
    }
    public void image_UD()
    {
        if(can_upDown)
        {
            if(check_up)
            {
                id_left = 0;
                id_right = 0;
                id_down = 0;
                remove_state();
                present_state = go_up[id_up];
                id_up = (id_up + 1)%3;
                check_up = false;
            }
            if(check_down)
            {
                id_left = 0;
                id_right = 0;
                id_up = 0;
                remove_state();
                present_state = go_down[id_down];
                id_down = (id_down + 1)%3;
                check_down = false;
            }
        }
    }
    public void image_LR()
    {
        if(can_leftRight)
        {
            if(check_left)
            {
                id_right = 0;
                id_up = 0;
                id_down = 0;
                remove_state();
                present_state = go_left[id_left];
                id_left = (id_left + 1)%3;
                check_left = false;
            }
            if(check_right)
            {
                id_up = 0;
                id_down = 0;
                id_left = 0;
                remove_state();
                present_state = go_right[id_right];
                id_right = (id_right + 1)%3;
                check_right = false;
            }
        }
    }
    public void die()
    {
        
    }
    public void change_IMG(Pair<Integer, Integer>move_number)
    {
        if(move_number.getKey() == -1 && move_number.getValue() == 0)
        {
            check_left = true;
            image_LR();
        }
        if(move_number.getKey() == 1 && move_number.getValue() == 0)
        {
            check_right = true;
            image_LR();
        }
        if(move_number.getKey() == 0 && move_number.getValue() == 1)
        {
            check_down = true;
            image_UD();
        }
        if(move_number.getKey() == 0 && move_number.getValue() == -1)
        {
            check_up = true;
            image_UD();
        }
    }
    public void set_Id(AbstractObject other)
    {
        id_right = other.id_right;
        id_up = other.id_up;
        id_down = other.id_down;
        id_left = other.id_left;
    }
    public boolean check_bomb(int x, int y, List<Bomb>bomb)
    {
        for(int i = 0;i < bomb.size();++i)
        {
            int bomb_x = (int)((bomb.get(i).object_X + bomb.get(i).distance_X)/bomb.get(i).object_width);
            int bomb_y = (int)((bomb.get(i).object_Y + bomb.get(i).distance_Y)/bomb.get(i).object_height);
            if(bomb_x == x && bomb_y == y) return true;
        }
        return false;
    }
    public void bomb_kill(Bomb player_bomb)
    {
        boolean check = false;
        if(player_bomb.boom_exist && player_bomb.time_waitExploded <= 0 && player_bomb.time_exploded > 0 && !check_die)
        {
            int x_col = (int)((player_bomb.object_X + player_bomb.distance_X)/player_bomb.object_width);
            int y_row = (int)((player_bomb.object_Y + player_bomb.distance_Y)/player_bomb.object_height);
            int X_col = (int)((object_X + distance_X)/ object_width);
            int Y_row = (int)((object_Y + distance_Y) / object_height);
            for(int i  =  x_col - player_bomb.flame_size;i <= x_col + player_bomb.flame_size;++i)
            {
                if(X_col == i && Y_row == y_row && player_bomb.check[y_row][i] == 1) check = true;
                if(check) break;
            }
            if(!check)
            {
                for(int i = y_row - player_bomb.flame_size;i <= y_row + player_bomb.flame_size;++i)
                {
                    if(X_col == x_col && Y_row == i && player_bomb.check[i][x_col] == 1) check = true;
                    if(check) break;
                }
            }
            if(check) 
            {
                check_die = true;
                //System.out.println("fuck");
            }
        }
    }
    public boolean check_collision(List<AbstractObject>enemy)
    {
        int X = (int)(object_X  + distance_X);
        int Y = (int)(object_Y + distance_Y);
        for(int i = 0;i < enemy.size();++i)
        {
            int enemy_X = (int)(enemy.get(i).object_X + enemy.get(i).distance_X);
            int enemy_Y = (int)(enemy.get(i).object_Y + enemy.get(i).distance_Y);
            boolean checkCollision = X >= enemy_X + enemy.get(i).object_width || enemy_X >= X + object_width;
            checkCollision = checkCollision ||  Y >= enemy_Y + enemy.get(i).object_height || enemy_Y >= Y + object_height;
            if(!checkCollision) return true;
        }
        return false;
    }
    public AbstractObject[][] state_die(AbstractObject[][] other)
    {
        AbstractObject[][] new_object = other;
        if(check_die)
        {
            move_able = false;
            //System.out.println(id_die);
            if(id_die < size_imgDie - 1) present_state = dead[id_die++];
            else
            {
                render_orNot = false;
                check_die = false;
            }
        }
        return new_object;
    }
    int[] speed = {12, 8, 6, 4, 2};
    int max_speed = 4;
    int size_speed = 1;
    public void real_move()
    {
        int X_round = (int)((object_X + distance_X) / object_width);
        int Y_round = (int)((object_Y + distance_Y) / object_height);
        if(X_round * object_width == object_X + distance_X && Y_round * object_height == object_Y + distance_Y && count_move >= 3) 
        {
            count_move = 0;
            step = -1;
            check_move = false;
        }
        if(step != -1)
        {
            //System.out.println(distance_X);
            //System.out.println(distance_Y);
            distance_X += (int)((id_move[step][change_X] * object_width) / speed[size_speed]);
            distance_Y += (int)((id_move[step][change_Y] * object_height) / speed[size_speed]);
            count_move +=1;
            change_IMG(new Pair<Integer, Integer>(id_move[step][change_X], id_move[step][change_Y]));
        }
    }
}
