/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author DELL
 */
import java.util.List;
import java.util.Random;
import javafx.scene.image.Image;
import javafx.scene.canvas.*;
import javafx.scene.canvas.GraphicsContext;
import javafx.util.Pair;
public class Balloon extends Kondoria {
    Balloon(){}
    Balloon(double x, double y, double width, double height, String name)
    {
        super(x, y, width, height, name);
        check_balloon = true;
    }
}
