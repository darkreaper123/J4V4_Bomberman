/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author DELL
 */
import javafx.scene.image.Image;
import javafx.scene.canvas.*;
import javafx.scene.canvas.GraphicsContext;
import javafx.util.Pair;
public class Item extends Object{
    char item;
    Item()
    {
        
    }
    Item(int x,int y, int width,int height, char item)
    {
        super(x, y , width, height, " ", false, false, false);
        this.item = item;
        if(item == 'b') present_state = new Image("powerup_bombs.png", width, height, false, false);
        if(item == 'f') present_state = new Image("powerup_flames.png", width, height, false, false);
        if(item == 's') present_state = new Image("powerup_speed.png", width, height, false, false);
    }
    public Player upgrade(Player win)
    {
        Player copy = win;
        if(item == 'b') copy.save_numberBomb++;
        if(item == 'f') copy.flame_size++;
        if(item == 's') copy.size_speed += (copy.size_speed < copy.max_speed ? 1 : 0);
        return copy;
    }
}
