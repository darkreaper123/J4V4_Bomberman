/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author DELL
 */
public class Brick extends CanBreaked {
    Brick(double x, double y, double width, double height)
    {
        super(x, y, width, height, "brick");
    }
    public AbstractObject[][] state_die(AbstractObject[][] other, Bomb player_bomb)
    {
        bomb_kill(player_bomb);
        AbstractObject[][] new_object = super.state_die(other);
        if(!render_orNot)
        {
            int x_col = (int)(object_X / object_width);
            int y_row = (int)(object_Y / object_height);
            new_object[y_row][x_col] = new Grass(object_width * x_col, object_height * y_row, object_width, object_height);
        }
        render_orNot = true;
        return new_object;
    }
}
